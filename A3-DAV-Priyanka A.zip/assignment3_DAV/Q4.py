import numpy as np

array= np.random.normal(size=(3, 4))
print (array)
