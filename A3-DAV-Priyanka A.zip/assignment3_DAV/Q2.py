import numpy as np

array = np.arange(10, 23, 2)
print (array)