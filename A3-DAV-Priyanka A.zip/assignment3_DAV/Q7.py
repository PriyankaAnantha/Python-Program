import pandas as pd

dict= {'P':1, 'R':2, 'I':3, 'Y':4, 'A':5}

p_series= pd.Series(dict)
print (p_series)