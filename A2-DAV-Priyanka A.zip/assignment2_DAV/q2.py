original_list = [1, 2, 3, 4]
string_to_insert = "emp"
new_list = [string_to_insert + str(num) for num in original_list]
print(new_list)