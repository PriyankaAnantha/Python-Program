minimum_value = 1
maximum_value = 100

divisible_by_7_and_8 = []

integer_list = [i for i in range(minimum_value, maximum_value+1) if i>0]

for integer in integer_list:
    if integer % 7 == 0 and integer % 8 == 0:
        divisible_by_7_and_8.append(integer)

print("Numbers divisible by 7 and 8: ", divisible_by_7_and_8)
